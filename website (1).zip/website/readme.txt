este site e para conseguir o script autofarm agredeça ao @juninhorip1337



     feito por @juninhorip1337

@copirythy juninhorrip1337